import sys
import time
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.widget import Widget
from kivy.uix.textinput import TextInput
from kivy.uix.relativelayout import RelativeLayout


class MainWindow(Screen):
    pass


class SecondWindow(Screen):
    pass


class ThirdWindow(Screen):
    pass

f = open('intermediate_conversor.txt','r')
k = f.readlines()
filename = k[0]
f.close()

input_file = open(filename,'r')
notes_list = input_file.readlines()
flashcard_dictionary = {}
counter1 = 0
counter2 = 1
for note in notes_list:
    counter1 += 1
    flashcard_dictionary[counter1] = note  #generating a dictionary: each pair is a single flashcard

class FourthWindow(Screen):
    partition = flashcard_dictionary[1].split(':>=<>=<:')
    starter = partition[0]

    def flip(self):
        reference = self.ids.word.text
        print(reference)
        for number in flashcard_dictionary:
            partition = flashcard_dictionary[number].split(':>=<>=<:')
            if reference == partition[0].strip():
                starter = partition[1].strip()
                self.ids.word.text = partition[1].strip()
            elif reference == partition[1].strip():
                starter = partition[0].strip()
                self.ids.word.text = partition[0].strip()             
  
    def left_note(self):
        reference = self.ids.word.text
        len_list = 0
        c2 = 0
        for number in flashcard_dictionary:
            len_list += 1
            partition = flashcard_dictionary[number].split(':>=<>=<:')
            if reference == partition[0].strip():
                c2 = number
            elif reference == partition[1].strip():
                c2 = number
        c2 = (c2 - 1)%len_list
        if c2 == 0:
            c2 = len_list
        partition = flashcard_dictionary[c2].split(':>=<>=<:')
        starter = partition[0].strip()
        self.ids.word.text = partition[0].strip() 

    def right_note(self):
        reference = self.ids.word.text
        len_list = 0
        c2 = 0
        for number in flashcard_dictionary:
            len_list += 1
            partition = flashcard_dictionary[number].split(':>=<>=<:')
            if reference == partition[0].strip():
                c2 = number
            elif reference == partition[1].strip():
                c2 = number
        c2 = (c2 + 1)%len_list
        if c2 == 0:
            c2 = len_list
        partition = flashcard_dictionary[c2].split(':>=<>=<:')
        starter = partition[0].strip()
        self.ids.word.text = partition[0].strip() 


class WindowManager(ScreenManager):
    pass


kv = Builder.load_file("my.kv")


class MyMainApp(App):
    def build(self):
        return kv

    def filefinder(self):
        field = self.root.get_screen("main").ids.field.text
        topic = self.root.get_screen("main").ids.topic.text
        subtopic = self.root.get_screen("main").ids.subtopic.text
        filename = field.lower() + '_' + topic.lower() + '_' + subtopic.lower() + '.txt'

        print(filename)
        
        field = self.root.get_screen("main").ids.field.text
        topic = self.root.get_screen("main").ids.topic.text
        subtopic = self.root.get_screen("main").ids.subtopic.text
        filename = field.lower() + '_' + topic.lower() + '_' + subtopic.lower() + '.txt'
        
        f = open('intermediate_conversor.txt','w+')
        f.write(filename)
        f.close()


    def noteadder(self):
        field = self.root.get_screen("main").ids.field.text
        topic = self.root.get_screen("main").ids.topic.text
        subtopic = self.root.get_screen("main").ids.subtopic.text
        filename = field.lower() + '_' + topic.lower() + '_' + subtopic.lower() + '.txt'
        
        f = open(filename,'a+')
        key = self.root.get_screen("second").ids.key.text
        details = self.root.get_screen("second").ids.details.text
        note = key + ':>=<>=<:' + details + '\n'
        print(note)
        f.write(note)
        f.close()


    def flashcards(self):
        field = self.root.get_screen("main").ids.field.text
        topic = self.root.get_screen("main").ids.topic.text
        subtopic = self.root.get_screen("main").ids.subtopic.text
        filename = field.lower() + '_' + topic.lower() + '_' + subtopic.lower() + '.txt'
        
        f = open('intermediate_conversor.txt','w+')
        f.write(filename)
        f.close()


    def noteprinter(self):
        field = self.root.get_screen("main").ids.field.text
        topic = self.root.get_screen("main").ids.topic.text
        subtopic = self.root.get_screen("main").ids.subtopic.text
        filename = field.lower() + '_' + topic.lower() + '_' + subtopic.lower() + '.txt'
        
        f = open('intermediate_conversor.txt','w+')
        f.write(filename)
        f.close()
        exec(open("noteprinter.py").read())
        
        time.sleep(0.5)
        short_filename = filename.replace('_','-')
        output_file = 'notes_for_' + short_filename
        print('Notes produced! You can find them in the same folder as this, labelled as:', output_file)
        print('\n')
        print('Notes:')
        
        newlist = []
        input_file = open(filename,'r')
        list_of_notes = input_file.readlines()
        for note in list_of_notes:
            newnote = note.replace(':>=<>=<:',' : ')
            newlist.append(newnote)
        input_file.close()
        for element in newlist:
            print(element)
            

if __name__ == "__main__":
    MyMainApp().run()



#https://www.reddit.com/r/kivy/comments/hztzyw/comment/fzlmz4w/?context=3
#https://stackoverflow.com/questions/63145740/how-do-i-pull-text-from-an-text-field-in-kivy-using-a-second-screen
#https://stackoverflow.com/questions/45097225/how-to-use-pos-hint-with-floatlayout-in-kivy
#https://groups.google.com/g/kivy-users/c/4vNNAevzwYM?pli=1
#
