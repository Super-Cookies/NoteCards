f = open('intermediate_conversor.txt','r')
k = f.readlines()
filename = k[0]
f.close()


newlist = []

input_file = open(filename,'r')
list_of_notes = input_file.readlines()

for note in list_of_notes:
    newnote = note.replace(':>=<>=<:',' : ')
    newlist.append(newnote)

input_file.close()



short_filename = filename.replace('_','-')
newfilename = 'Notes_for_' + short_filename

output_file = open(newfilename, 'w+')

for element in newlist:
    output_file.write(element)

output_file.close()
